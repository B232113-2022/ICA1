#!/bin/bash

RAWDATA_PATH="./rawdata/"
FASTQC_PATH="./fastqc_outputs/"

mkdir -p $FASTQC_PATH
pigz -d $RAWDATA_PATH*.gz

# iterate over all fastq format files to perform fastqc
for FILE in $RAWDATA_PATH*.fq
do 
  FASTQ=${FILE/$RAWDATA_PATH/}
  FASTQC=${FASTQ/.fq/_fastqc.zip}

  # check if fastqc zip compressed files already exists to avoid unnecessary repitition of a quality check
  if ! [ -f "$FASTQC_PATH$FASTQC" ] ; then
    fastqc -t 100 -o $FASTQC_PATH ${FILE}
  fi
done

unzip "$FASTQC_PATH*.zip" -d $FASTQC_PATH
rm -rf $FASTQC_PATH*.zip
