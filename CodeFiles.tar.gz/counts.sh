#!usr/bin/bash

BED="./Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019.bed"
BAM_PATH="./bam_outputs/"
OUTPUT_PATH="./"
INDEX="./Tcongo_genome/Tcongo"

mkdir -p $OUTPUT_PATH

# use bedtools using all BAM files in the directory
BAM_LIST=$(ls $BAM_PATH*.bam)
bedtools multicov -bams $BAM_LIST -bed $BED > bed_reads_$(basename $INDEX)

# counts of reads are generated using an awk script
awk -f count_reads.awk bed_reads_$(basename $INDEX) > read_counts_per_gene.txt
