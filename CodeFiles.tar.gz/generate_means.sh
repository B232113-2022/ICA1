#!usr/bin/bash

GROUPS_INPUT="./groups_columns"
INDEX="./Tcongo_genome/Tcongo"
BED_INPUT="bed_reads_Tcongo"
MEAN_OUTPUT="mean_per_group"

# generate headers and their corresponding columns
HEADER="GENE_OF_INTEREST\tGENE_DESCRIPTION"
cut -f 4,5 $BED_INPUT > $MEAN_OUTPUT

# iterate over groups
while IFS=$'\t' read -r GROUP COL
do
  HEADER+="\t"$GROUP  # extend the header

  # cut relevant columns according to the comma delimited column indicators stored in the line.
  # calculate the mean using awk
  # paste the mean column to the gene name/description
  cut -f $COL $BED_INPUT | \
  awk 'BEGIN{FS="\t"}{sum=0; for (i=1; i<=NF; i++) {sum+=$i;} print sum/NF;}' | \
  paste $MEAN_OUTPUT - > "temp"
  cat "temp" > $MEAN_OUTPUT
done < $GROUPS_INPUT

# insert header to the first line of the file
sed -i "1i $HEADER" $MEAN_OUTPUT
rm -rf "temp"
