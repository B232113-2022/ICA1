#!usr/bin/bash

IFS=$'\t'
PAIR_INPUT="comparison_pairs"
MEAN_INPUT="mean_per_group"
BED_INPUT="bed_reads_Tcongo"
OUTPUT_DIR="./fold_changes_per_pair/"

mkdir -p $OUTPUT_DIR

# iterate over lines of pairs
while IFS=$'\t' read -r PAIR1 PAIR2
do
  FOLD_OUTPUT="fold_changes_"$PAIR1"_and_"$PAIR2
  cut -f 4,5 $BED_INPUT > $OUTPUT_DIR$FOLD_OUTPUT   # gene name/description are stored as first two columns

  # FNR==1 means that for the first line, generate a header-column array so that columns can be accessed using header names.
  # column values are adjusted to 1 if they are zero, so that "division by zero" is not an issue.
  # calculate fold changes.
  # adjust all negative fold change values to positive ones.
  awk -v p1=$PAIR1 -v p2=$PAIR2 'BEGIN{FS="\t"} FNR==1{for (i=1; i<=NF; i++) {col[$i]=i;} ; next}{{ $(col[p1]) = ($(col[p1]) == 0 ? 1 : $(col[p1])) } { $(col[p2]) = ($(col[p2]) == 0 ? 1 : $(col[p2])) } fold=$(col[p1])/$(col[p2])-1; print fold < 0 ? -fold : fold;}' $MEAN_INPUT | \
  paste $OUTPUT_DIR$FOLD_OUTPUT - > "temp"    # paste columns to the gene name/description
  cat "temp" > $OUTPUT_DIR$FOLD_OUTPUT

  # sort the final file accoring to the third column, which are the fold change values
  sort -t $'\t' -k 3,3 -nro $OUTPUT_DIR$FOLD_OUTPUT $OUTPUT_DIR$FOLD_OUTPUT
done < $PAIR_INPUT

rm -rf "temp"
